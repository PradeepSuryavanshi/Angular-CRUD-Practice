﻿using EmployeeAPIAngular.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace EmployeeAPIAngular.Controllers
{
    [RoutePrefix("Api/Employee")]
    public class EmployeeController : ApiController
    {
        [HttpGet]
        public HttpResponseMessage AllEmployeeDetails()
        {
            using (AngularCRUDEntities objEntity = new AngularCRUDEntities())
            {
                return Request.CreateResponse(HttpStatusCode.OK, objEntity.tblEmployeeMasters.ToList());
            }
        }
        [HttpGet]
        public HttpResponseMessage GetEmployeeDetailsById(int id)
        {
            using (AngularCRUDEntities objEntity = new AngularCRUDEntities())
            {
                var entity = objEntity.tblEmployeeMasters.FirstOrDefault(e => e.EmpId == id);
                if (entity != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, entity);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound, $"Employee with ID {id} not found");
                }

            }
        }
        [HttpPut]
        public HttpResponseMessage UpdateEmployeeDetails(int id, [FromBody] tblEmployeeMaster employee)
        {
            try
            {
                using (AngularCRUDEntities objEntity = new AngularCRUDEntities())
                {
                    var entity = objEntity.tblEmployeeMasters.FirstOrDefault(e => e.EmpId == id);

                    if (entity == null)
                    {
                        return Request.CreateResponse(HttpStatusCode.NotFound, "Employee with Id " + id.ToString() + " not found to update");
                    }
                    else
                    {
                        entity.FirstName = employee.FirstName;
                        entity.LastName = employee.LastName;
                        entity.Address = employee.Address;
                        entity.EmailId = employee.EmailId;
                        entity.DateofBirth = employee.DateofBirth.HasValue ? employee.DateofBirth.Value.AddDays(1) : (DateTime?)null;
                        entity.Gender = employee.Gender;
                        entity.CountryId = employee.CountryId;
                        entity.StateId = employee.StateId;
                        entity.Cityid = employee.Cityid;
                        entity.Pincode = employee.Pincode;

                        objEntity.SaveChanges();

                        return Request.CreateResponse(HttpStatusCode.OK, entity);
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, ex);
            }

        }
        [HttpPost]
        public HttpResponseMessage InsertEmployeeDetails([FromBody] tblEmployeeMaster employee)
        {
            try
            {
                using (AngularCRUDEntities objEntity = new AngularCRUDEntities())
                {
                    objEntity.tblEmployeeMasters.Add(employee);
                    objEntity.SaveChanges();
                    var message = Request.CreateResponse(HttpStatusCode.Created, employee);

                    return message;
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }

        }
        [HttpDelete]
        public HttpResponseMessage DeleteEmployeeDetails(int id)
        {
            try
            {
                using (AngularCRUDEntities objEntity = new AngularCRUDEntities())
                {
                    var entity = objEntity.tblEmployeeMasters.FirstOrDefault(e => e.EmpId == id);
                    if (entity == null)
                    {
                        return Request.CreateResponse(HttpStatusCode.NotFound, "Employee with Id = " + id.ToString() + " not found to delete");
                    }
                    else
                    {
                        objEntity.tblEmployeeMasters.Remove(objEntity.tblEmployeeMasters.FirstOrDefault(e => e.EmpId == id));
                        objEntity.SaveChanges();
                        return Request.CreateResponse(HttpStatusCode.OK);
                    }

                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }

        }
        [HttpGet]
        [Route("Country")]
        public HttpResponseMessage GetCountry()
        {
            using (AngularCRUDEntities objEntity = new AngularCRUDEntities())
            {
                return Request.CreateResponse(HttpStatusCode.OK, objEntity.CountryMasters.ToList());
            }
        }
        [HttpGet]
        public List<CountryMaster> CountryData()
        {
            try
            {
                using (AngularCRUDEntities objEntity = new AngularCRUDEntities())
                {
                    return objEntity.CountryMasters.ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpGet]
        public HttpResponseMessage GetCountryById(int id)
        {
            using (AngularCRUDEntities objEntity = new AngularCRUDEntities())
            {
                var entity = objEntity.CountryMasters.FirstOrDefault(c => c.CountryId == id);
                if (entity != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, entity);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound, $"Country with ID {id} not found");
                }

            }
        }
        [Route("Country/{CountryId}/State")]
        [HttpGet]
        public List<StateMaster> StateData(int CountryId)
        {
            try
            {
                using (AngularCRUDEntities objEntity = new AngularCRUDEntities())
                {
                    return objEntity.StateMasters.Where(s => s.CountryId == CountryId).ToList();
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [Route("State/{StateId}/City")]
        [HttpGet]
        public List<CityMaster> CityData(int StateId)
        {
            try
            {
                using (AngularCRUDEntities objEntity = new AngularCRUDEntities())
                {
                    return objEntity.CityMasters.Where(s => s.StateId == StateId).ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}