import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/employee.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-edit-employee',
  templateUrl: './edit-employee.component.html',
  styleUrls: ['./edit-employee.component.css']
})
export class EditEmployeeComponent implements OnInit {
  emailFormControl = new FormControl('', [Validators.required, Validators.email]);
  currentEmployee!: Employee;
  alert:boolean = false;
  message = '';

  constructor(
    private employeeService: EmployeeService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.message = '';
    this.getEmployee(this.route.snapshot.paramMap.get('id'));
  }

  getEmployee(id: any):void{
    this.employeeService.read(id)
    .subscribe(
      employee => {
        this.currentEmployee = employee;
        console.log(employee);
      },
      error => {
        console.log(error);
        });
  }

  setAvailableStatus(status:any): void {
    const data = {
    name: this.currentEmployee.FirstName,
    description: this.currentEmployee.EmpId,
    available: status
    };
  }
    

  updateEmployee( ): void {
     this.employeeService.update(this.currentEmployee.EmpId, this.currentEmployee)
     .subscribe(
     response => {
     console.log(response);
     this.message = 'The Employee Data is Updated!';
     this.alert=true;
     },
     error => {
     console.log(error);
     });
  }

  deleteEmployee(): void {
    this.employeeService.delete(this.currentEmployee.EmpId)
    .subscribe(
    response => {
      console.log(response);
      this.router.navigate(['/AllEmployeeDetails']);
      this.message = 'The Employee Data is Deleted!';
      this.alert=true;
    },
    error => {
      console.log(error);
    });
  }

  closeAlert():void {
    this.alert =false;
  }
      

}


