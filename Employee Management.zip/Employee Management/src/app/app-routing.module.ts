import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { ListEmployeeComponent } from './list-employee/list-employee.component';
import { EditEmployeeComponent } from './edit-employee/edit-employee.component';
import { AboutComponent } from './about/about.component';

const routes: Routes = [
  { path:'', component:AboutComponent},
  { path:'AboutUs', component:AboutComponent},
  { path: 'InsertEmployeeDetails', component:AddEmployeeComponent},
  { path: 'AllEmployeeDetails',
    children:[  
      { path: '', component:ListEmployeeComponent},
      { path: 'UpdateEmployeeDetails/:id', component:EditEmployeeComponent}
    ] 
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
