export class Employee {
  EmpId: string | undefined;
  FirstName: string | undefined;
  LastName: string | undefined;
  DateofBirth: string | undefined;
  EmailId: string | undefined;
  Gender: string | undefined;
  CountryId: string | undefined;
  StateId: string | undefined;
  CityId: string | undefined;
  Address: string | undefined;
  Pincode: string | undefined;
  Country: string | undefined;
  State: string | undefined;
  City: string | undefined;
}

export class Country {
  CountryId: string | undefined;
  CountryName: string | undefined;
}

export class State {
  StateId: string | undefined;
  StateName: string | undefined;
  CountryId: string | undefined;
}

export class City {
  Cityid: string | undefined;
  CityName: string | undefined;
  StateId: string | undefined;
  CountryId: string | undefined;
}
