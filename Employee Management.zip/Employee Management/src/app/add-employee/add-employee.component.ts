import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { EmployeeService } from 'src/app/employee.service';
@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  emailFormControl = new FormControl('', [Validators.required, Validators.email]);
  employee ={
    EmpId: '',
    FirstName: '',
    LastName: '',
    DateofBirth: '',
    EmailId: '',
    Gender: '',
    CountryId: '',
    StateId: '',
    CityId: '',
    Address: '',
    Pincode: '',
    Country: '',
    State: '',
    City: '',
  };
  submitted = false;

  constructor(private employeeService:EmployeeService) { }

  ngOnInit(): void {
  }

  createEmployee(): void {
    const data = {
      EmpId: this.employee.EmpId,
      FirstName: this.employee.FirstName,
      LastName: this.employee.LastName,
      DateofBirth: this.employee.DateofBirth,
      EmailId: this.employee.EmailId,
      Gender: this.employee.Gender,
      CountryId: this.employee.CountryId,
      StateId: this.employee.StateId,
      CityId: this.employee.CityId,
      Address: this.employee.Address,
      Pincode: this.employee.Pincode,
      Country: this.employee.Country,
      State: this.employee.State,
      City: this.employee.City,
    };
    this.employeeService.create(data)
    .subscribe(
    response => {
    console.log(response);
    this.submitted = true;
    },
    error => {
    console.log(error);
    });
    }
    newEmployee(): void {
    this.submitted = false;
    this.employee = {
      EmpId: '',
      FirstName: '',
      LastName: '',
      DateofBirth: '',
      EmailId: '',
      Gender: '',
      CountryId: '',
      StateId: '',
      CityId: '',
      Address: '',
      Pincode: '',
      Country: '',
      State: '',
      City: '',
    };
    }

}
