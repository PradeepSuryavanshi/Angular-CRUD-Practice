import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-list-employee',
  templateUrl: './list-employee.component.html',
  styleUrls: ['./list-employee.component.css']
})
export class ListEmployeeComponent implements OnInit {

  employees: any;
  currentEmployee:Employee | undefined;
  currentIndex = -1;

  constructor(private employeeService:EmployeeService) { }

  ngOnInit(): void {
    this.readEmployees();
  }
  readEmployees(): void {
    this.employeeService.readAll().subscribe(employees => {
    this.employees = employees;
    console.log(employees);
    },
    error => {
    console.log(error);
    });
  }
  refresh(): void {
    this.readEmployees();
    this.currentEmployee = undefined;
    this.currentIndex = -1;
  }
  setCurrentEmployee(employee:Employee, index:number): void {
    this.currentEmployee = employee;
    this.currentIndex = index;
  }

}
