import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee, State,City } from './employee';
import { Country } from './employee';



@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  baseURL = 'https://localhost:44318/Api/Employee';

  constructor(private httpClient: HttpClient) { }

  readAll(): Observable<any>{
    return this.httpClient.get(`${this.baseURL}/${'AllEmployeeDetails'}`);
  }

  read(id:number): Observable<any>{
    return this.httpClient.get(`${this.baseURL}/${'GetEmployeeDetailsById'}/${id}`);
  }

  create(data:Employee): Observable<any>{
    return this.httpClient.post(`${this.baseURL}/${'InsertEmployeeDetails'}`,data);
  }

  update(id:string|undefined,data:Employee): Observable<any>{
    return this.httpClient.put(`${this.baseURL}/${'UpdateEmployeeDetails'}/${id}`,data);
  }

  delete(id:string|undefined): Observable<any>{
    return this.httpClient.delete(`${this.baseURL}/${'DeleteEmployeeDetails'}/${id}`);
  }

}
